(function($) { $(function() {    

}) })(jQuery)




window.addEventListener('load', () => {
   
});